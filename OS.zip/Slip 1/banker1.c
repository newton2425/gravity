#include<stdio.h>

int main()
{
 int i,j,choice;
 
 int allocation[5][3] = {{ 0, 1, 0},
                         { 2, 0, 0},
                         { 3, 0, 2},
                         { 2, 1, 1},
                         { 0, 0, 2}};
  
  int max[5][3] = {{ 7, 5, 3},
                   { 3, 2, 2},
                   { 9, 0, 2},
                   { 2, 2, 2},
                   { 4, 3, 3}};
    
 int need[5][3];
 int available[3] = {3,3,2};
 
 for(i=0;i<5;i++)
 {
  for(j=0;j<3;j++)
  {
   need[i][j] = max[i][j] - allocation[i][j];
  }
 }
 
 do
 {
    printf("\n------MENU-------\n");
    printf("1.Accept Available\n");
    printf("2.Display Allocation And Max\n");
    printf("3.Display Need Matrix\n");
    printf("4.Display Available\n");
    printf("5.Exit\n");
    printf("Enter Your Choice: ");
    scanf("%d",&choice);
    
    switch (choice)
    {
    case 1:
          printf("Enter Available Resources(A,B,C):");
          scanf("%d %d %d", &available[0] , &available[1], &available[2]);
          break;
          
    case 2:
         printf("\nAllocation Matrix:\n");
         printf("  \tA\tB\tC\n");
         for(i=0;i<5;i++)
         {
           printf("P%d",i);
           for(j=0;j<3;j++)
             printf("\t%d",allocation[i][j]);
           printf("\n");
         }
         
          printf("\nMax Matrix:\n");
          printf("  \tA\tB\tC\n");
          for(i=0;i<5;i++)
          {
            printf("P%d",i);
            for(j=0;j<3;j++)
              printf("\t%d",max[i][j]);
            printf("\n");
          }
          break;
         
    case 3:
         printf("\nNeed  Matrix:\n");
         printf("  \tA\tB\tC\n");
         for(i=0;i<5;i++)
         {
           printf("P%d",i);
           for(j=0;j<3;j++)
             printf("\t%d",need[i][j]);
           printf("\n");
         }
         break;
    
    case 4:
          printf("\nAvailable Resources:\n");
          printf("  \tA\tB\tC\n");
          printf("\t%d\t%d\t%d\n",available[0] , available[1], available[2]);
          break;
          
   case 5:
         printf("Exiting Program......\n");
         break;
         
   default: 
        printf("Invalid Choice:\n");
    }
   }while (choice !=5);
   
   return 0;
}
  
