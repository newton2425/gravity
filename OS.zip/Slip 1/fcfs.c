#include <stdio.h>
#include <stdlib.h>

int main()
{
  int n, head, total_blocks;
  int i;
  int total_movement = 0;
  
  printf("Enter total number of disk blocks (up to 200) :");
  scanf("%d",&total_blocks);
  
  printf("Enter number of disk requests: ");
  scanf("%d",&n);
  
  int request[n];
  
  printf("Enter disk request sequence:\n");
  for(i=0;i<n;i++)
  {
    scanf("%d",&request[i]);
  }
  
  printf("Enter initial head position:");
  scanf("%d",&head);
  
  printf("\n Request Serving order: \n");
  printf("%d",head);
  
  for(i=0;i<n;i++)
  {
    total_movement += abs(request[i] - head);
    head = request[i];
    printf("->%d",head);
  }
  
  printf("\n\n Total Number of head movement =%d\n",total_movement);
  
  return 0;
}

