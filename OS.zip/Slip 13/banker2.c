#include <stdio.h>

int main()
{
    int i, j, k;
    int n=5;
    int m=4;
    
    int alloc[5][4]={{0,0,1,2},
                     {1,0,0,0},
                     {1,3,5,4},
                     {0,6,3,2},
                     {0,0,1,4}};
    
    int max[5][4]={{0,0,1,2},
                   {1,7,5,0},
                   {2,3,5,6},
                   {0,6,5,2},
                   {0,6,5,6}};
                   
    int avail[4]={1,5,2,0};
    int need[5][4];
    int finish[5]={0};
    int safeSeq[5];
    int count=0;
    
    for(i=0; i<n; i++)
        for(j=0; j<m; j++)
            need[i][j] = max[i][j] - alloc[i][j];
            
    printf("Allocation Matrix:\n");
    for(i=0; i<n; i++)
    {
        for(j=0; j<m; j++)
            printf("%d\t",alloc[i][j]);
        printf("\n");
    }
    
    printf("\nMax Matrix:\n");
    for(i=0; i<n; i++)
    {
        for(j=0; j<m; j++)
            printf("%d\t",max[i][j]);
        printf("\n");
    }
    printf("\nNeed Matrix:\n");
    for(i=0; i<n; i++)
    {
        for(j=0; j<m; j++)
            printf("%d\t",need[i][j]);
        printf("\n");
    }
    
    while(count < n)
    {
        int found = 0;
        for(i=0; i<n; i++)
        {
            if(!finish[i])
            {
                for(j=0; j<m; j++)
                    if(need[i][j] > avail[j])
                    break;
                
                if(j==m)
                {
                    for(k=0; k<m; k++)
                        avail[k] += alloc[i][k];
                        
                    safeSeq[count++]=i;
                    finish[i]=1;
                    found=1;
                }
            }
        }
        if(!found)
        {
            printf("\nSystem is NOT in a safe state\n");
            return 0;
        }
    }
        printf("System is in SAFE state\nSafe sequence: ");
        for(i=0; i<n; i++)
            printf("-->P%d",safeSeq[i]);
            
        return 0;
}
