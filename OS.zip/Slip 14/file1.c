#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define MAX 20

int n;
int bitVector[MAX];

struct file
{
 char name[20];
 int start;
 int length;
}dir[MAX];

int fileCount = 0;

void showBitVector()
{
 int i;
 printf("\nBit Vector\n");
 for(i = 0; i < n; i++)
 {
  printf("%d",bitVector[i]);
 }
 printf("\n");
}


void showDirectory()
{
 int i;
 if(fileCount == 0)
 { 
  printf("\nDirectory is empty\n");
  return;
 }
 
 printf("\nDirectory:\n");
 printf("FileName\tStartBlock\tLength\n");
 for(i = 0; i < fileCount; i++)
 {
  printf("%s\t\t%d\t\t%d\n",dir[i].name,dir[i].start,dir[i].length);
 }
}

void createFile()
{
 char fname[20];
 int len,i,j,start=-1;
 
 printf("\nEnter File name:");
 scanf("%s",fname);
 
 printf("Enter file length(number of blocks): ");
 scanf("%d",&len);
 
 for(i=0;i<=n-len;i++)
 {
  int free = 1;
  for(j=i;j<i+len;j++)
  {
   if(bitVector[j]==1)
   { 
    free = 0;
    break;
   }
  }
  if(free)
  {
   start = i;
   break;
  }
 }
 if(start==-1)
 {
  printf("Not enough contiguous free space!\n");
  return;
 }
 
 for(i=start;i<start+len;i++)
   bitVector[i]=1;
   
 strcpy(dir[fileCount].name,fname);
 dir[fileCount].start=start;
 dir[fileCount].length=len;
 fileCount++;
 
 printf("File Created successfully!\n");
}


void deleteFile()
{
 char fname[20];
 int i,j,found=-1;
 
 printf("\nEnter file name to delete:");
 scanf("%s",fname);
 
 for(i=0;i<fileCount;i++)
 {
  if(strcmp(dir[i].name,fname)==0)
  {
   found=i;
   break;
  }
 }
 
 if(found==-1)
 {
  printf("File not found!\n");
  return;
 }
 
 for(j=dir[found].start;j<dir[found].start+dir[found].length;j++)
 {
  bitVector[j]=0;
 }
 
 for(i=found;i<fileCount-1;i++)
 {
  dir[i]=dir[i+1];
 }
 
 fileCount--;
 printf("File deleted successfully!\n");
}

int main()
{
 int choice,i;
 
 printf("Enter number of disk blocks:");
 scanf("%d",&n);
 
 srand(time(NULL));
 for(i=0;i<n;i++)
   bitVector[i]=rand()%2;
   
 do
 {
  printf("\n---Menu---");
  printf("\n1. Show bit Vector");
  printf("\n2. Create new file");
  printf("\n3. Delete file");
  printf("\n4. Show Directory");
  printf("\n5. Exit");
  printf("\n Enter your choice:");
  scanf("%d",&choice);
  
  switch(choice)
  {
   case 1:
        showBitVector();
        break;
   case 2:
        createFile();
        break;
   case 3:
        deleteFile();
        break;
   case 4:
        showDirectory();
        break;
   case 5:
        printf("Exiting program...\n");
        break;
   default:
        printf("Invalid Choice!\n");
   }
  }
  while(choice!=5);
  
  return 0;
}
