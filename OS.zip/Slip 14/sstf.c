#include <stdio.h>
#include <stdlib.h>

int main()
{
  int n,i, head, total_blocks;
  int req[50], visited[50] = {0};
  int totalMovement = 0;
  
  printf("Enter total number of disk blocks (up to 200) :");
  scanf("%d",&total_blocks);
  
  printf("Enter number of disk requests: ");
  scanf("%d",&n);
  
  printf("Enter disk request sequence:\n");
  for(i=0;i<n;i++)
  {
    scanf("%d",&req[i]);
  }
  
  printf("Enter initial head position:");
  scanf("%d",&head);
  
  printf("\n Request of serving order:\n");
  printf("%d",head);
  
  for(i=0;i<n;i++)
  {
    int minDist = 9999;
    int index = -1;
    
    for(int j=0;j<n;j++)
    {
      if (visited[j] == 0)
      {
       int dist = abs(head - req[j]);
       if(dist < minDist)
       {
         minDist = dist;
         index = j;
       }
      }
    }
    
    visited[index] = 1;
    totalMovement  += abs(req[index] - head);
    head = req[index];
    
    printf("->%d",head);
  }
  
  printf("\n\n Total Number of head movement =%d\n",totalMovement);
  
  return 0;
}

  
  
  
