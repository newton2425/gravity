#include <stdio.h>
#include <stdlib.h>

int main()
{
    int disk_size, n, head, direction;
    int request[100];
    int i, j, temp;
    int total_movement = 0;
    int index = 0;

    printf("Enter total number of disk blocks: ");
    scanf("%d", &disk_size);

    printf("Enter number of requests: ");
    scanf("%d", &n);

    printf("Enter the request sequence:\n");
    for(i = 0; i < n; i++)
    {
        scanf("%d", &request[i]);
    }

    printf("Enter current head position: ");
    scanf("%d", &head);

    printf("Enter direction (0 for Left, 1 for Right): ");
    scanf("%d", &direction);

      for(i = 0; i < n - 1; i++)
    {
        for(j = 0; j < n - i - 1; j++)
        {
            if(request[j] > request[j + 1])
            {
                temp = request[j];
                request[j] = request[j + 1];
                request[j + 1] = temp;
            }
        }
    }

    for(i = 0; i < n; i++)
    {
        if(request[i] > head)
        {
            index = i;
            break;
        }
    }

    printf("\nOrder of service:\n");
    printf("%d ", head);

    if(direction == 1)  
    {
        for(i = index; i < n; i++)
        {
            printf("-> %d ", request[i]);
            total_movement += abs(head - request[i]);
            head = request[i];
        }

        total_movement += abs(head - (disk_size - 1));
        head = disk_size - 1;
        printf("-> %d ", head);

        total_movement += abs(head - 0);
        head = 0;
        printf("-> %d ", head);


        for(i = 0; i < index; i++)
        {
            printf("-> %d ", request[i]);
            total_movement += abs(head - request[i]);
            head = request[i];
        }
    }

    else  
    {
        for(i = index - 1; i >= 0; i--)
        {
            printf("-> %d ", request[i]);
            total_movement += abs(head - request[i]);
            head = request[i];
        }

        total_movement += abs(head - 0);
        head = 0;
        printf("-> %d ", head);

        total_movement += abs(head - (disk_size - 1));
        head = disk_size - 1;
        printf("-> %d ", head);

        for(i = n - 1; i >= index; i--)
        {
            printf("-> %d ", request[i]);
            total_movement += abs(head - request[i]);
            head = request[i];
        }
    }

    printf("\n\nTotal Head Movement = %d\n", total_movement);

    return 0;
}

