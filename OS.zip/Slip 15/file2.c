#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define MAX 100

int n;
int bitVector[MAX];
int nextBlock[MAX];

struct directory
{
 char fname[20];
 int start;
}dir[MAX];

int dirCount = 0;

void showBitVector()
{
 printf("\nBit Vector:\n");
 for(int i=0;i<n;i++)
 {
  printf("%d",bitVector[i]);
 }
 printf("\n");
}



void createFile()
{
 char name[20];
 int size,first =-1,prev =-1;
 
 printf("\nEnter file name:");
 scanf("%s",name);
 
 printf("Enter number of blocks needed:");
 scanf("%d",&size);
 
 int count=0;
 for(int i=0;i<n && count<size;i++)
 {
  if(bitVector[i]==0)
  {
   bitVector[i]==1;
   if(first == -1)
     first =i;
   if(prev != -1)
     nextBlock[prev] = i;
   prev = i;
   nextBlock[i] = -1;
   count++;
  }
 }
 
 if(count<size)
 {
  printf("Not enough free blocks!\n");
  return;
 }
 
 strcpy(dir[dirCount].fname,name);
 dir[dirCount].start=first;
 dirCount++;
 
 printf("File created successfully!\n");
}


void showDirectory()
{
 printf("\nDirectory:\n");
 printf("File Name\tBlocks\n");
 
 for(int i=0;i<dirCount;i++)
 {
  printf("%s\t\t",dir[i].fname);
  int block = dir[i].start;
  while(block != -1)
  {
   printf("%d",block);
   block=nextBlock[block];
  }
  printf("\n");
 }
}


int main()
{
 int choice;
 
 printf("Enter number of disk blocks:");
 scanf("%d",&n);
 
 srand(time(NULL));
 
 for(int i=0;i<n;i++)
 {
  bitVector[i] = rand() % 2;
  nextBlock[i] = -1;
 }
 
 do
 {
  printf("\n---Linked File Allocation---\n");
  printf("1.Show Bit Vector\n");
  printf("2.Create New File\n");
  printf("3.Show Directory\n");
  printf("4.Exit\n");
  printf("Enter Choice:");
  scanf("%d",&choice);
  
  switch(choice)
  {
  case 1:
       showBitVector();
       break;
 case 2:
       createFile();
       break;
 case 3:
      showDirectory();
      break;
 case 4:
      printf("Exiting----\n");
      break;
 default:
      printf("Invalid choice!\n");
  }
 }while(choice !=4);
 
 return 0;
}
