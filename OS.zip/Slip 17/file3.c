#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#define MAX_FILES 10
#define MAX_BLOCKS 100

int bitVector[MAX_BLOCKS];
int n;
struct file 
{
    char name[20];
    int indexBlock;
    int blocks[20];
    int blockCount;
} 
dir[MAX_FILES];
int fileCount = 0;

void showBitVector() 
{
    int i;
    printf("\nBit Vector:\n");
    for (i = 0; i < n; i++)
        printf("%d ", bitVector[i]);
    printf("\n");
}

void createFile() 
{
    int i, j, blocksNeeded, count = 0;
    struct file f;
    if (fileCount >= MAX_FILES) 
    {
        printf("Directory Full!\n");
        return;
    }
    printf("Enter file name: ");
    scanf("%s", f.name);

    printf("Enter number of blocks needed: ");
    scanf("%d", &blocksNeeded);

    /* Find index block */
    for (i = 0; i < n; i++)
    {
        if (bitVector[i] == 0)
        {
            f.indexBlock = i;
            bitVector[i] = 1;
            break;
        }
    }
    for (j = 0; j < n && count < blocksNeeded; j++)
    {
        if (bitVector[j] == 0) {
            f.blocks[count++] = j;
            bitVector[j] = 1;
        }
    }
    if (count < blocksNeeded)
    {
        printf("Not enough free blocks!\n");
        return;
    }
    f.blockCount = blocksNeeded;
    dir[fileCount++] = f;

    printf("File created successfully!\n");
}

void showDirectory() 
{
    int i, j;
    if (fileCount == 0)
    {
        printf("Directory is empty!\n");
        return;
    }
    printf("\nDirectory:\n");
    for (i = 0; i < fileCount; i++) 
    {
        printf("File Name: %s\n", dir[i].name);
        printf("Index Block: %d\n", dir[i].indexBlock);
        printf("Data Blocks: ");
        for (j = 0; j < dir[i].blockCount; j++)
            printf("%d ", dir[i].blocks[j]);
        printf("\n\n");
    }
}

void deleteFile() 
{
    char name[20];
    int i, j, found = -1;
    printf("Enter file name to delete: ");
    scanf("%s", name);
    for (i = 0; i < fileCount; i++)
    {
        if (strcmp(dir[i].name, name) == 0) 
        {
            found = i;
            break;
        }
    }
    if (found == -1) 
    {
        printf("File not found!\n");
        return;
    }
    bitVector[dir[found].indexBlock] = 0;
    for (j = 0; j < dir[found].blockCount; j++)
        bitVector[dir[found].blocks[j]] = 0;
    for (i = found; i < fileCount - 1; i++)
        dir[i] = dir[i + 1];
    fileCount--;
    printf("File deleted successfully!\n");
}

int main()
{
    int choice, i;
    printf("Enter number of disk blocks: ");
    scanf("%d", &n);
    srand(time(0));
    for (i = 0; i < n; i++)
        bitVector[i] = rand() % 2;

    do 
    {
        printf("\n--- Indexed File Allocation ---\n");
        printf("1. Show Bit Vector\n");
        printf("2. Create New File\n");
        printf("3. Show Directory\n");
        printf("4. Delete File\n");
        printf("5. Exit\n");
        printf("Enter choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1: showBitVector(); break;
            case 2: createFile(); break;
            case 3: showDirectory(); break;
            case 4: deleteFile(); break;
            case 5: printf("Exiting...\n"); break;
            default: printf("Invalid choice!\n");
        }
    } 
    while (choice != 5);

    return 0;
}
