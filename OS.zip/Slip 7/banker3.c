#include<stdio.h>

int main()
{
  int i,j;
  int n=5;
  int m=4;
  
  
  int alloc[5][4]= {
                    {2,0,0,1},
                    {3,1,2,1},
                    {2,1,0,3},
                    {1,3,1,2},
                    {1,4,3,2}
                    };
                    
  int max[5][4]= {
                   {4,2,1,2},
                   {5,2,5,2},
                   {2,3,1,6},
                   {1,4,2,4},
                   {3,6,6,5}
                   };
  
  int avai[4]={7,4,3,6};
  
  int need[5][4];
  for(i = 0; i < n; i++)
   for(j = 0; j < m; j++)
    need[i][j] = max[i][j]-alloc[i][j];
    
  int finish[5]={0};
  int safeseq[5];
  int count=0;
  
  while(count < n)
  {
   int found=0;
   for(i = 0; i < n; i++)
   {
    if(!finish[i])
    {
     for(j = 0; j < m; j++)
       if(need[i][j] > avai[j])
        break;
        
        
     if(j == m)
     {
      for(j = 0; j < m; j++)
        avai[j] += alloc[i][j];
      
      safeseq[count++] = i;
      finish[i]=1;
      found = 1;
     }
    }
   }
   
   if(!found)
   {
    printf("\nsystem is NOT in safe state\n");
    return 0;
   }
  }
  
  
  printf("\n system is in safe state\nsafe sequence:\n ");
  for(i = 0; i < n; i++)
    printf("\tP%d\n",safeseq[i]);
    
  return 0;
}
  
                 
  
