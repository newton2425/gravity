// Program 2: Employee Swing + JDBC
 
import javax.swing.*; 
import java.awt.*; 
import java.awt.event.*; 
import java.sql.*; 
class EmpForm extends JFrame implements ActionListener { 
JTextField eno, ename, edesg, esal; 
JButton btnInsert; 
Connection con=null; 
PreparedStatement ps=null; 
EmpForm() { 
setLayout(new FlowLayout()); 
eno=new JTextField(10); 
ename=new JTextField(10); 
edesg=new JTextField(10); 
esal=new JTextField(10); 
btnInsert=new JButton("Insert"); 
add(new JLabel("Eno")); add(eno); 
add(new JLabel("Name")); add(ename); 
add(new JLabel("Desg")); add(edesg); 
add(new JLabel("Salary")); add(esal); 
add(btnInsert); 
btnInsert.addActionListener(this); 
try{ 
con=DriverManager.getConnection( 
"jdbc:postgresql://localhost:5432/TYCS","postgres","ACS"); 
}catch(Exception e){} 
setSize(300,300); 
setVisible(true); 
} 
public void actionPerformed(ActionEvent e){ 
try{ 
ps=con.prepareStatement("insert into employee values(?,?,?,?)"); 
ps.setInt(1,Integer.parseInt(eno.getText())); 
ps.setString(2,ename.getText()); 
ps.setString(3,edesg.getText()); 
ps.setDouble(4,Double.parseDouble(esal.getText())); 
ps.executeUpdate(); 
JOptionPane.showMessageDialog(this,"Inserted"); 
}catch(Exception ex){} 
} 
} 
class Slip1Q2 { 
public static void main(String args[]){ 
EmpForm ef=new EmpForm(); 
} 
} 