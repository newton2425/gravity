// Program 1: Servlet Customer Search 

import java.io.*; 
import javax.servlet.*; 
import javax.servlet.http.*; 
import java.sql.*; 
 
class SearchCustomerServlet extends HttpServlet { 
 
    Connection con=null; 
    PreparedStatement ps=null; 
    ResultSet rs=null; 
 
    public void init(){ 
        try{ 
            con=DriverManager.getConnection( 
            "jdbc:postgresql://localhost:5432/TYCS","postgres","ACS"); 
        }catch(Exception e){} 
    } 
 
    public void doPost(HttpServletRequest req,HttpServletResponse res) 
    throws ServletException,IOException{ 
 
        PrintWriter out=res.getWriter(); 
        int cno=Integer.parseInt(req.getParameter("cno")); 
 
        try{ 
            ps=con.prepareStatement("select * from customer where cno=?"); 
            ps.setInt(1,cno); 
 
            rs=ps.executeQuery(); 
 
            if(rs.next()) 
                out.println("Found: "+rs.getString(2)); 
            else 
                out.println("Not Found"); 
        }catch(Exception e){} 
    } 
} 