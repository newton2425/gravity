//  Program 1: Thread Name & Priority 

class ThreadInfo extends Thread { 
    public void run(){ 
        System.out.println("Name: "+getName()); 
        System.out.println("Priority: "+getPriority()); 
    } 
} 
 
class Slip15Q1{ 
    public static void main(String args[]){ 
        ThreadInfo t=new ThreadInfo(); 
        t.start(); 
    } 
} 