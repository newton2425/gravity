//  Program 2: Servlet Visit Counter 

import java.io.*; 
import javax.servlet.*; 
import javax.servlet.http.*; 
 
class VisitServlet extends HttpServlet { 
 
    public void doGet(HttpServletRequest req,HttpServletResponse res) 
    throws ServletException,IOException{ 
 
        PrintWriter out=res.getWriter(); 
 
        Cookie ck[]=req.getCookies(); 
        int count=1; 
 
        if(ck!=null){ 
            count=Integer.parseInt(ck[0].getValue()); 
            count++; 
        } 
 
        Cookie c=new Cookie("visit",""+count); 
        res.addCookie(c); 
 
        if(count==1) 
            out.println("Welcome First Time"); 
        else 
            out.println("Visited "+count+" times"); 
    } 
}