//  Program 1: TreeSet Colors 

import java.util.*; 
 
class ColorOp { 
    void show(){ 
        TreeSet<String> ts=new TreeSet<>(); 
 
        ts.add("Red"); 
        ts.add("Blue"); 
        ts.add("Green"); 
 
        System.out.println(ts); 
    } 
} 
 
class Slip16Q1{ 
    public static void main(String args[]){ 
        ColorOp co=new ColorOp(); 
        co.show(); 
    } 
} 