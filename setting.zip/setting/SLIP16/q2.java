 //  Program 2: Teacher PreparedStatement 

import java.sql.*; 
 
class TeacherOp { 
 
    Connection con=null; 
    PreparedStatement ps=null; 
    ResultSet rs=null; 
 
    TeacherOp(){ 
        try{ 
            con=DriverManager.getConnection( 
            "jdbc:postgresql://localhost:5432/TYCS","postgres","ACS"); 
 
            ps=con.prepareStatement("select * from teacher where 
subject='JAVA'"); 
            rs=ps.executeQuery(); 
 
            while(rs.next()){ 
                System.out.println(rs.getString(2)); 
            } 
        }catch(Exception e){} 
} 
} 
class Slip16Q2{ 
public static void main(String args[]){ 
TeacherOp to=new TeacherOp(); 
} 
} 