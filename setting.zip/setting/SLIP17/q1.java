// Program 1: Unique Sorted Integers 

import java.util.*; 
class NumOp { 
void perform(){ 
TreeSet<Integer> set=new TreeSet<>(); 
set.add(10); 
set.add(5); 
set.add(10); 
System.out.println(set); 
} 
} 
class Slip17Q1{ 
public static void main(String args[]){ 
NumOp no=new NumOp(); 
no.perform(); 
} 
} 