// Program 2: Swing Number Display 

import javax.swing.*; 
import java.awt.*; 
import java.awt.event.*; 
class NumDisplay extends JFrame implements Runnable,ActionListener { 
JTextField tf; 
JButton btn; 
Thread t; 
NumDisplay(){ 
setLayout(new FlowLayout()); 
tf=new JTextField(20); 
btn=new JButton("Start"); 
add(tf); add(btn); 
btn.addActionListener(this); 
        setSize(300,200); 
        setVisible(true); 
    } 
 
    public void actionPerformed(ActionEvent e){ 
        t=new Thread(this); 
        t.start(); 
    } 
 
    public void run(){ 
        try{ 
            for(int i=1;i<=100;i++){ 
                tf.setText(""+i); 
                Thread.sleep(100); 
            } 
        }catch(Exception e){} 
    } 
} 
 
class Slip17Q2{ 
    public static void main(String args[]){ 
        NumDisplay nd=new NumDisplay(); 
    } 
} 