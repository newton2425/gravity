//  Program 2: Servlet Student Result 

import java.io.*; 
import javax.servlet.*; 
import javax.servlet.http.*; 
 
class StudServlet extends HttpServlet { 
 
    public void doPost(HttpServletRequest req,HttpServletResponse res) 
    throws ServletException,IOException{ 
 
        PrintWriter out=res.getWriter(); 
 
        int total=Integer.parseInt(req.getParameter("total")); 
        double per=total/5.0; 
 
        String grade="Fail"; 
 
        if(per>=60) grade="A"; 
        else if(per>=50) grade="B"; 
        else if(per>=40) grade="C"; 
 
        out.println("Per: "+per); 
        out.println("Grade: "+grade); 
    } 
} 