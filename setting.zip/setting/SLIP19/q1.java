//  Program 1: Negative Integers 

import java.util.*; 
 
class NegOp { 
    void perform(){ 
        LinkedList<Integer> list=new LinkedList<>(); 
 
        list.add(10); 
        list.add(-5); 
        list.add(-2); 
 
        for(int num:list){ 
            if(num<0) 
                System.out.println(num); 
        } 
    } 
} 
 
class Slip19Q1{ 
    public static void main(String args[]){ 
        NegOp no=new NegOp(); 
        no.perform(); 
    } 
}