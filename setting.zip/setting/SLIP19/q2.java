// Program 2: Servlet Login 

import java.io.*; 
import javax.servlet.*; 
import javax.servlet.http.*; 
import java.sql.*; 
class LoginServlet extends HttpServlet { 
Connection con=null; 
PreparedStatement ps=null; 
ResultSet rs=null; 
public void init(){ 
try{ 
con=DriverManager.getConnection( 
"jdbc:postgresql://localhost:5432/TYCS","postgres","ACS"); 
}catch(Exception e){} 
} 
public void doPost(HttpServletRequest req,HttpServletResponse res) 
throws ServletException,IOException{ 
PrintWriter out=res.getWriter(); 
String uname=req.getParameter("uname"); 
String pass=req.getParameter("pass"); 
try{ 
ps=con.prepareStatement( 
"select * from users where uname=? and pass=?"); 
ps.setString(1,uname); 
ps.setString(2,pass); 
rs=ps.executeQuery(); 
if(rs.next()) 
out.println("Success"); 
else 
out.println("Failed"); 
}catch(Exception e){} 
} 
} 