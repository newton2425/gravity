// Program 1: Menu Driven JDBC 

import java.sql.*; 
import java.util.*; 
class EmpMenu { 
    Connection con=null; 
    Statement st=null; 
    ResultSet rs=null; 
 
    EmpMenu(){ 
        try{ 
            con=DriverManager.getConnection( 
            "jdbc:postgresql://localhost:5432/TYCS","postgres","ACS"); 
 
            st=con.createStatement(); 
            Scanner sc=new Scanner(System.in); 
 
            while(true){ 
                int ch=sc.nextInt(); 
 
                if(ch==1) 
                    st.executeUpdate("insert into emp 
values(1,'Amit',5000)"); 
                else if(ch==2) 
                    st.executeUpdate("update emp set salary=6000 where 
eno=1"); 
                else if(ch==3){ 
                    rs=st.executeQuery("select * from emp"); 
                    while(rs.next()) 
                        System.out.println(rs.getInt(1)); 
                } 
                else break; 
            } 
        }catch(Exception e){} 
    } 
} 
 
class Slip22Q1{ 
    public static void main(String args[]){ 
        EmpMenu em=new EmpMenu(); 
    } 
}