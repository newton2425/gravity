//  Program 2: JSP Greeting 

<%@ page import="java.util.*" %> 
<html> 
<body> 
<form method="post"> 
<input type="text" name="name"> 
<input type="submit"> 
</form> 
 
<% 
String name=request.getParameter("name"); 
 
if(name!=null){ 
Date d=new Date(); 
int h=d.getHours(); 
 
if(h<12){ 
%><h3>Good Morning <%= name %></h3><% 
}else if(h<18){ 
%><h3>Good Afternoon <%= name %></h3><% 
}else{ 
%><h3>Good Evening <%= name %></h3><% 
} 
} 
%> 
</body> 
</html>