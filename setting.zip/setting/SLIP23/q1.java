// Program 1: Vowel Multithreading 

class VowelThread extends Thread { 
String str; 
VowelThread(String str){ this.str=str; } 
public void run(){ 
try{ 
for(int i=0;i<str.length();i++){ 
char ch=str.charAt(i); 
if("AEIOUaeiou".indexOf(ch)!=-1){ 
System.out.println(ch); 
Thread.sleep(3000); 
} 
} 
}catch(Exception e){} 
} 
} 
class Slip23Q1{ 
public static void main(String args[]){ 
VowelThread vt=new VowelThread("Hello"); 
vt.start(); 
} 
} 