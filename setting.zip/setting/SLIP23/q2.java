// Program 2: Iterator & ListIterator 

import java.util.*; 
class StudOp { 
void perform(String args[]){ 
ArrayList<String> list=new ArrayList<>(); 
for(String s:args) 
list.add(s); 
Iterator<String> it=list.iterator(); 
while(it.hasNext()) 
System.out.println(it.next()); 
} 
} 
class Slip23Q2{ 
public static void main(String args[]){
    StudOp so=new StudOp(); 
so.perform(args); 
}
}