// Program 1: Delete Employee 

import java.sql.*; 
class DeleteEmp { 
Connection con=null; 
PreparedStatement ps=null; 
DeleteEmp(int eno){ 
try{ 
con=DriverManager.getConnection( 
"jdbc:postgresql://localhost:5432/TYCS","postgres","ACS"); 
ps=con.prepareStatement("delete from emp where eno=?"); 
ps.setInt(1,eno); 
ps.executeUpdate(); 
}catch(Exception e){} 
} 
} 
class Slip26Q1{ 
public static void main(String args[]){ 
DeleteEmp de=new DeleteEmp(Integer.parseInt(args[0])); 
} 
} 