// Program 2: JSP Sum First & Last 

<html> 
<body> 
<form method="post"> 
<input type="text" name="num"> 
<input type="submit"> 
</form> 
<% 
String n=request.getParameter("num"); 
if(n!=null){ 
int num=Integer.parseInt(n); 
int last=num%10; 
int first=num; 
while(first>=10) first/=10; 
int sum=first+last; 
%> 
<p style="color:red;font-size:18px;"> 
<%= sum %> 
</p> 
<% } %> 
</body> 
</html> 