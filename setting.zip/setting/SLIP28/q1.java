// Program 1: JSP Reverse String 


<html> 
<body> 
<form method="post"> 
<input type="text" name="str"> 
<input type="submit"> 
</form> 
<% 
String s=request.getParameter("str"); 
if(s!=null){ 
String rev=""; 
for(int i=s.length()-1;i>=0;i--){ 
rev+=s.charAt(i); 
} 
%> 
<h3><%= rev %></h3> 
<% } %> 
</body> 
</html> 