// Program 1: ResultSetMetaData 


import java.sql.*; 
 
class DonarMeta { 
 
    Connection con=null; 
    Statement st=null; 
    ResultSet rs=null; 
 
    DonarMeta(){ 
        try{ 
            con=DriverManager.getConnection( 
            "jdbc:postgresql://localhost:5432/TYCS","postgres","ACS"); 
 
            st=con.createStatement(); 
            rs=st.executeQuery("select * from donar"); 
 
            ResultSetMetaData md=rs.getMetaData(); 
            int col=md.getColumnCount(); 
 
            for(int i=1;i<=col;i++){ 
                System.out.println(md.getColumnName(i)); 
            } 
        }catch(Exception e){} 
    } 
} 
 
class Slip29Q1{ 
    public static void main(String args[]){ 
        DonarMeta dm=new DonarMeta(); 
    } 
} 