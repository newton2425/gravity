//  Program 2: LinkedList Integer Ops 

import java.util.*; 
 
class IntListOp { 
    void perform(){ 
        LinkedList<Integer> list=new LinkedList<>(); 
 
        list.addFirst(10); 
        list.add(20); 
        list.add(30); 
 
        list.removeLast(); 
 
        System.out.println("Size: "+list.size()); 
    } 
} 
 
class Slip29Q2{ 
    public static void main(String args[]){ 
        IntListOp io=new IntListOp(); 
        io.perform(); 
    } 
} 