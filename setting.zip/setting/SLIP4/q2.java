// Program 2: City STD Code 

import java.util.*; 
class CityOp { 
void perform() { 
HashMap<String,Integer> map=new HashMap<>(); 
map.put("Surat",261); 
map.put("Mumbai",22); 
map.remove("Mumbai"); 
String cname="Surat"; 
if(map.containsKey(cname)) 
System.out.println(map.get(cname)); 
else 
System.out.println("Not found"); 
} 
} 
class Slip4Q2 { 
public static void main(String args[]){ 
CityOp co=new CityOp(); 
co.perform(); 
} 
} 


