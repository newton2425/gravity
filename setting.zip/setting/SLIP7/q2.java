//  Program 2: JDBC Product 

import java.sql.*; 
 
class ProductOp { 
 
    Connection con=null; 
    Statement st=null; 
    ResultSet rs=null; 
 
    ProductOp() { 
        try{ 
            con=DriverManager.getConnection( 
            "jdbc:postgresql://localhost:5432/TYCS","postgres","ACS"); 
 
            st=con.createStatement(); 
 
            rs=st.executeQuery("select * from product"); 
 
            while(rs.next()){ 
                System.out.println(rs.getInt(1)+" "+rs.getString(2)); 
            } 
        }catch(Exception e){} 
    } 
} 
 
class Slip7Q2 { 
    public static void main(String args[]){ 
        ProductOp po=new ProductOp(); 
    } 
}